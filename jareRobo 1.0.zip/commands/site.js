const Discord = require("discord.js");
 
exports.run = (client, message, args) => {

const desc = '`🐊` https://jarerobo.glitch.me `🐊`'

message.channel.send(desc);
}